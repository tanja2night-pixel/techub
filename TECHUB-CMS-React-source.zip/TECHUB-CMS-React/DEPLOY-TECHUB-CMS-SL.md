# TECHUB – React + WordPress CMS (testno okolje)

WordPress na https://cms.22digital.agency/ je že nameščen in vtičnik TecHub CMS aktiviran. Ne nameščaj WordPressa v glavno domeno.

## Preverjanje CMS
- Novice: https://cms.22digital.agency/wp-json/wp/v2/news
- Prostori: https://cms.22digital.agency/wp-json/wp/v2/spaces
- Časovnica: https://cms.22digital.agency/wp-json/wp/v2/timeline
- Nastavitve: https://cms.22digital.agency/wp-json/techub/v1/settings

## Izgradnja in namestitev na testno stran
Priloženi ZIP je **izvorna koda, ne že zgrajena mapa `dist`**. Pred cPanelom jo je treba zgraditi na računalniku z Node.js in internetno povezavo ali v Kimi AI:

1. V WordPressu popravi testni naslov novice ali ustvari novo novico (SL/EN, povezava).
2. Razpakiraj projekt in v projektni mapi (kjer je `package.json`) zaženi `npm ci` ter `npm run build`. Nastane nova mapa `dist`.
3. V NEOSERV File Managerju najprej naredi varnostno kopijo trenutne testne strani na 22digital.agency.
4. **V dokumentni koren `22digital.agency` naloži VSEBINO** nove mape `dist` (`index.html`, mapo `assets`, mapo `images`), ne mape `dist` kot podmape. Ne nalagaj v mapo `cms.22digital.agency`.
5. Odpri https://22digital.agency/ v zasebnem zavihku ali s hard refresh in preveri slovensko/angleško različico, novice in prostore.
6. V WP spremeni naslov testne novice; po osvežitvi testne strani mora biti nova vsebina vidna. Če ne, preveri Network/Console v brskalniku.

Če uporabljaš Kimi AI namesto Terminala: naloži **celoten ta izvorni ZIP** in zahtevaj `npm ci && npm run build`, izvoz **nove** mape `dist` brez sprememb oblikovanja. Prej priloženi `app/dist.zip` je stara zgrajena stran, **ne vsebuje te nove CMS povezave**.

## Vsebine
- Novice: WP je primarni vir; ob API izpadu se prikažejo stare, v kodi shranjene novice.
- Prostori: WordPress vtičnik ustvari samo vzorčni Coworking. Ostalih pet originalnih kartic ostane iz kode, dokler vseh šest prostorov ne vneseš v WordPress. Nove karte se lahko dodajajo, obstoječe povezuješ po URL slugih.
- Časovnica: prikazana je izvorna, dokler nimaš objav pod Timeline. CMS različica trenutno omogoča urejanje naslova, datumske oznake in faze; podrobni seznami niso del nameščenega WordPress vtičnika.
- Settings → TecHub: hero, statistika, kontaktni e-mail/naslov in napis financiranja/nosilca. Prazna polja uporabijo izvirna besedila.
- Meniji, kontaktni obrazec, programi, opisni odseki in dialogi niso del tega CMS vtičnika in ostanejo kot izvorna koda.

## Izvorna koda
V projektni mapi: `npm ci && npm run build`, kopiraj novo mapo `dist` na testno domeno. URL API-ja je v `.env.production` (javni naslov, ne geslo). Če CMS kasneje preseliš na `cms.techub.si`, spremeni `.env.production` in ponovno zgradi projekt. Nikoli ne dodajaj WordPress gesel v React.

**Ne spreminjaj produkcijske strani `techub.si` pred preizkusom testne domene.**
