import { useEffect, useState } from 'react';
import { getNews, type CmsNews } from '../cms';
import { useLanguage } from '../contexts/LanguageContext';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { Calendar, ArrowRight, Newspaper, ExternalLink } from 'lucide-react';

interface NewsItem {
  id: number;
  title: string;
  date: string;
  excerpt: string;
  image?: string;
  featured: boolean;
  link: string;
}

export function News() {
  const { language } = useLanguage();
  const { ref: titleRef, isVisible: titleVisible } = useScrollAnimation();

  const fallbackNewsItems: NewsItem[] = language === 'sl' ? [
    {
      id: 1,
      title: 'SAŠA regija z novima inkubatorjema odpira prostor startupom in visokotehnološkim podjetjem',
      date: '25. 5. 2026',
      excerpt: 'SAŠA inkubator je na največji startup in tehnološki konferenci v regiji Podim predstavil dva nova razvojna projekta v Velenju – Staro elektrarno – Center prihodnosti in Tehnološki park Velenje – TecHub. Oba inkubatorja bosta podjetnikom, startupom in inovatorjem ponujala sodobno podporno okolje, mentorstvo, razvojne laboratorije, coworking prostore ter povezovanje z raziskovalnimi in gospodarskimi partnerji.',
      image: '/images/Banner_TEC_SECP_01-m.jpg',
      featured: true,
      link: 'https://www.velenje.si/sasa-regija-z-novima-inkubatorjema-odpira-prostor-startupom-in-visokotehnoloskim-podjetjem/',
    },
    {
      id: 2,
      title: 'Zaključeno betoniranje temeljne plošče tehnološkega parka Velenje',
      date: '16. 2. 2026',
      excerpt: 'Gradnja Tehnološkega parka Velenje – TecHub, enega ključnih razvojnih projektov v okviru pravičnega prehoda SAŠA regije, napreduje po predvidenem terminskem načrtu. Na gradbišču je izvajalec uspešno zaključil betoniranje temeljne plošče, ki je bilo zaradi velikosti in zahtevnosti objekta izvedeno v dveh fazah. Za temeljno ploščo je bilo uporabljenih približno 2.000 m³ betona.',
      image: 'https://www.velenje.si/app/uploads/2026/02/Tehnoloski-2-1500x1125.png',
      featured: true,
      link: 'https://www.velenje.si/zakljuceno-betoniranje-temeljne-plosce-tehnoloskega-parka-velenje/',
    },
    {
      id: 3,
      title: 'Skupaj gradimo sodobno in napredno mesto za bivanje',
      date: '5. 11. 2025',
      excerpt: 'V Ekonomsko-poslovni coni Stara vas nastaja Tehnološki park Velenje – TecHub, ki bo obsegal šest tehnoloških celic s pisarnami za prve proizvodne in testne procese, Smart Media Lab za plasiranje produktov na trg, sodobno konferenčno dvorano ter prostore za inovativna podjetja.',
      image: 'https://www.velenje.si/app/uploads/2025/11/image00001.jpeg',
      featured: true,
      link: 'https://www.velenje.si/novica/skupaj-gradimo-sodobno-in-napredno-mesto-za-bivanje',
    },
    {
      id: 4,
      title: 'Začenjamo z gradnjo Tehnološkega parka Velenje – TecHub',
      date: '11. 9. 2025',
      excerpt: 'Danes smo v Velenju podpisali dve pogodbi, s katerima se uradno začenjajo dela pri izgradnji Tehnološkega parka Velenje – TecHub, ki nastaja v soinvestitorstvu s Kemijskim inštitutom. Gre za enega ključnih projektov prestrukturiranja SAŠA regije. Podpisani sta bili pogodbi za Izgradnjo tehnološkega parka in Storitve svetovalnega inženirja in nadzornika pri izgradnji. Gradbena dela bodo končana decembra 2026, celoten projekt pa junija 2027.',
      image: 'https://www.velenje.si/app/uploads/2025/09/podpis-10-9-25-1.jpg',
      featured: true,
      link: 'https://www.velenje.si/zacenjamo-z-gradnjo-tehnoloskega-parka-velenje-techub/',
    },
    // Previous news - listed as links only
    {
      id: 5,
      title: 'Predstavnikom Vlade predstavili temeljne razvojne projekte',
      date: '7. 10. 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/predstavnikom-vlade-predstavili-temeljne-razvojne-projekte',
    },
    {
      id: 6,
      title: 'Z inkubatorji do novega gospodarskega preboja Šaleške doline',
      date: '21. 8. 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/z-inkubatorji-do-novega-gospodarskega-preboja-saleske-doline',
    },
    {
      id: 7,
      title: 'O pravičnem prehodu z delovno skupino za spremljanje prestrukturiranja',
      date: '3. 7. 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/o-pravicnem-prehodu-z-delovno-skupino-za-spremljanje-prestrukturiranja',
    },
    {
      id: 8,
      title: 'Aktivno izvajamo projekte povezane s pravičnim prehodom',
      date: '18. 6. 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/aktivno-izvajamo-projekte-povezane-s-pravicnim-prehodom',
    },
    {
      id: 9,
      title: 'Iščemo izvajalca gradbenih del za nov tehnološki park v Velenju',
      date: '27. 12. 2024',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/iscemo-izvajalca-gradbenih-del-za-nov-tehnoloski-park-v-velenju',
    },
    {
      id: 10,
      title: 'Korak bližje do novega tehnološkega parka',
      date: '11. 4. 2024',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/korak-blizje-do-novega-tehnoloskega-parka',
    },
  ] : [
    {
      id: 1,
      title: 'SAŠA region opens space for startups and high-tech companies with two new incubators',
      date: 'May 25, 2026',
      excerpt: 'SAŠA incubator presented two new development projects in Velenje at the region\'s largest startup and technology conference Podim – Stara Elektrarna – Center of the Future and Technology Park Velenje – TecHub. Both incubators will offer entrepreneurs, startups and innovators a modern support environment, mentorship, development laboratories, coworking spaces and connection with research and business partners.',
      image: '/images/Banner_TEC_SECP_01-m.jpg',
      featured: true,
      link: 'https://www.velenje.si/sasa-regija-z-novima-inkubatorjema-odpira-prostor-startupom-in-visokotehnoloskim-podjetjem/',
    },
    {
      id: 2,
      title: 'Foundation slab concreting of the Velenje Technology Park completed',
      date: 'February 16, 2026',
      excerpt: 'The construction of the Velenje Technology Park – TecHub, one of the key development projects within the just transition of the SAŠA region, is progressing according to the planned schedule. The contractor has successfully completed the foundation slab concreting, which was carried out in two phases due to the size and complexity of the building. Approximately 2,000 m³ of concrete was used for the foundation slab.',
      image: 'https://www.velenje.si/app/uploads/2026/02/Tehnoloski-2-1500x1125.png',
      featured: true,
      link: 'https://www.velenje.si/zakljuceno-betoniranje-temeljne-plosce-tehnoloskega-parka-velenje/',
    },
    {
      id: 3,
      title: 'Together we are building a modern and advanced city for living',
      date: 'November 5, 2025',
      excerpt: 'The Velenje Technology Park – TecHub is being built in the Stara vas Economic-Business Zone, and will include six technology cells with offices for initial production and testing processes, a Smart Media Lab for market product placement, a modern conference hall, and spaces for innovative companies.',
      image: 'https://www.velenje.si/app/uploads/2025/11/image00001.jpeg',
      featured: true,
      link: 'https://www.velenje.si/novica/skupaj-gradimo-sodobno-in-napredno-mesto-za-bivanje',
    },
    {
      id: 4,
      title: 'We are starting the construction of the Velenje Technology Park – TecHub',
      date: 'September 11, 2025',
      excerpt: 'Today in Velenje we signed two contracts that officially mark the beginning of the construction of the Velenje Technology Park – TecHub, which is being developed in co-investment with the Chemical Institute. This is one of the key projects for the restructuring of the SAŠA region. Construction work will be completed in December 2026, and the entire project by June 2027.',
      image: 'https://www.velenje.si/app/uploads/2025/09/podpis-10-9-25-1.jpg',
      featured: true,
      link: 'https://www.velenje.si/zacenjamo-z-gradnjo-tehnoloskega-parka-velenje-techub/',
    },
    // Previous news - listed as links only
    {
      id: 5,
      title: 'Presented fundamental development projects to Government representatives',
      date: 'October 7, 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/predstavnikom-vlade-predstavili-temeljne-razvojne-projekte',
    },
    {
      id: 6,
      title: 'With incubators to a new economic breakthrough of the Šalek Valley',
      date: 'August 21, 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/z-inkubatorji-do-novega-gospodarskega-preboja-saleske-doline',
    },
    {
      id: 7,
      title: 'About just transition with the working group for monitoring restructuring',
      date: 'July 3, 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/o-pravicnem-prehodu-z-delovno-skupino-za-spremljanje-prestrukturiranja',
    },
    {
      id: 8,
      title: 'Actively implementing projects related to just transition',
      date: 'June 18, 2025',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/aktivno-izvajamo-projekte-povezane-s-pravicnim-prehodom',
    },
    {
      id: 9,
      title: 'Looking for a contractor for the new technology park in Velenje',
      date: 'December 27, 2024',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/iscemo-izvajalca-gradbenih-del-za-nov-tehnoloski-park-v-velenju',
    },
    {
      id: 10,
      title: 'A step closer to the new technology park',
      date: 'April 11, 2024',
      excerpt: '',
      featured: false,
      link: 'https://www.velenje.si/novica/korak-blizje-do-novega-tehnoloskega-parka',
    },
  ];

  // WP is the source of truth when available; keep the existing news for outages.
  const [cmsNews, setCmsNews] = useState<CmsNews[] | null>(null);
  useEffect(() => {
    let active = true;
    setCmsNews(null);
    getNews(language).then(data => { if (active) setCmsNews(data); })
      .catch(error => { console.warn('TecHub CMS news unavailable; showing local news.', error); });
    return () => { active = false; };
  }, [language]);
  const newsItems: NewsItem[] = cmsNews ?? fallbackNewsItems;

  const featuredNews = newsItems.filter(item => item.featured);
  const listNews = newsItems.filter(item => !item.featured);

  return (
    <section id="news" className="py-24 bg-gradient-to-b from-techub-bg-light to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            {language === 'sl' ? 'Novice' : 'News'}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {language === 'sl' ? 'Spremljajte najnovejše informacije o razvoju TecHuba.' : 'Follow the latest information about TecHub development.'}
          </p>
        </div>

        {/* Featured News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {featuredNews.map((item, index) => (
            <FeaturedNewsCard key={item.id} item={item} index={index} />
          ))}
        </div>

        {/* News List */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <Newspaper className="w-5 h-5 text-techub-blue" />
              {language === 'sl' ? 'Prejšnje novice' : 'Previous news'}
            </h3>
          </div>
          <div className="divide-y divide-gray-100">
            {listNews.map((item, index) => (
              <NewsListItem key={item.id} item={item} index={index} />
            ))}
          </div>
        </div>

        {/* More Info Link */}
        <div className="mt-8 text-center">
          <a
            href="https://www.velenje.si/projects/tehnoloski-park-velenje-techub/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-techub-blue hover:text-techub-blue-dark font-medium transition-colors"
          >
            {language === 'sl' ? 'Za več informacij obiščite' : 'For more information visit'}
            <span className="underline">{language === 'sl' ? 'tehnoloski-park-velenje-techub' : 'techub project page'}</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}

interface FeaturedNewsCardProps {
  item: NewsItem;
  index: number;
}

function FeaturedNewsCard({ item, index }: FeaturedNewsCardProps) {
  const { ref, isVisible } = useScrollAnimation(0.2);
  const { language } = useLanguage();

  return (
    <a
      href={item.link}
      target="_blank"
      rel="noopener noreferrer"
      ref={ref as any}
      className={`group block transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-shadow overflow-hidden border border-gray-100 h-full">
        {/* Image */}
        <div className="relative h-52 overflow-hidden">
          {item.image && (
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          )}
          <div className="absolute top-3 right-3">
            <ExternalLink className="w-5 h-5 text-white/70 group-hover:text-white transition-colors" />
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
            <Calendar className="w-4 h-4" />
            <span>{item.date}</span>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-techub-blue transition-colors line-clamp-2">
            {item.title}
          </h3>
          <p className="text-gray-600 text-sm line-clamp-4 mb-4">
            {item.excerpt}
          </p>
          <div className="flex items-center text-techub-blue text-sm font-medium">
            <span>{language === 'sl' ? 'Preberi več' : 'Read more'}</span>
            <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>
    </a>
  );
}

interface NewsListItemProps {
  item: NewsItem;
  index: number;
}

function NewsListItem({ item, index }: NewsListItemProps) {
  const { ref, isVisible } = useScrollAnimation(0.1);

  return (
    <a
      href={item.link}
      target="_blank"
      rel="noopener noreferrer"
      ref={ref as any}
      className={`group block cursor-pointer px-6 py-4 hover:bg-gray-50 transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
      }`}
      style={{ transitionDelay: `${index * 50}ms` }}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-1">
            <Calendar className="w-4 h-4" />
            <span>{item.date}</span>
          </div>
          <h4 className="text-base font-semibold text-gray-900 group-hover:text-techub-blue transition-colors">
            {item.title}
          </h4>
        </div>
        <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-techub-blue flex-shrink-0 mt-5 opacity-0 group-hover:opacity-100 transition-all" />
      </div>
    </a>
  );
}
