import { useLanguage } from '../contexts/LanguageContext';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { MapPin } from 'lucide-react';

export function LocationMap() {
  const { language } = useLanguage();
  const { ref, isVisible } = useScrollAnimation();

  const title = language === 'sl' ? 'Kje smo' : 'Where we are';
  const subtitle = language === 'sl'
    ? 'Center Prihodnosti – Stara Elektrarna, Velenje'
    : 'Center of the Future – Stara Elektrarna, Velenje';

  return (
    <section className="py-16 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-3">
            <MapPin className="w-5 h-5 text-stone-500" />
            <h3 className="text-2xl md:text-3xl font-bold text-stone-800">{title}</h3>
          </div>
          <p className="text-stone-500">{subtitle}</p>
        </div>

        {/* Map Embed */}
        <div className="w-full rounded-2xl overflow-hidden shadow-lg border border-stone-200">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2752.9947094027884!2d15.098827176323738!3d46.36949297110323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765610037109239%3A0x88fe2a491f84ba5!2sTECHUB%20-%20Tehnolo%C5%A1ki%20park%20Velenje!5e0!3m2!1sen!2sus!4v1778627923325!5m2!1sen!2sus"
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="TecHub Velenje Location"
            className="w-full"
          />
        </div>
      </div>
    </section>
  );
}
