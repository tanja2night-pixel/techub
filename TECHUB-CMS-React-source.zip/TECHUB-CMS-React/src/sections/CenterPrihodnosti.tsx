import { useLanguage } from '../contexts/LanguageContext';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { ExternalLink, Leaf } from 'lucide-react';

export function CenterPrihodnosti() {
  const { language } = useLanguage();
  const { ref, isVisible } = useScrollAnimation();

  const title = language === 'sl'
    ? 'Stara Elektrarna – Center Prihodnosti'
    : 'Stara Elektrarna – Future Center';

  const description = language === 'sl'
    ? 'Vas zanimajo food tech, prehranske inovacije ali trajnostne rešitve?'
    : 'Interested in food tech, food labs or sustainable solutions?';

  const ctaText = language === 'sl'
    ? 'Obiščite centerprihodnosti.si'
    : 'Visit centerprihodnosti.si';

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Natural earthy background */}
      <div className="absolute inset-0 bg-stone-100" />

      {/* Subtle organic shapes */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-stone-200/40 rounded-full -translate-y-1/3 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-56 h-56 bg-stone-200/50 rounded-full translate-y-1/3 -translate-x-1/5" />
      <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-amber-100/30 rounded-full -translate-y-1/2" />

      <div
        ref={ref}
        className={`relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="flex flex-col lg:flex-row items-center gap-10">
          {/* Image */}
          <div className="w-full lg:w-2/5 flex-shrink-0">
            <div className="relative rounded-2xl overflow-hidden shadow-lg">
              <img
                src="/images/staraelektrarna.jpg"
                alt="Stara Elektrarna"
                className="w-full h-64 lg:h-72 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
          </div>

          {/* Content */}
          <div className="text-center lg:text-left flex-1">
            {/* Icon */}
            <div className="w-12 h-12 bg-stone-200 rounded-xl flex items-center justify-center mb-4 mx-auto lg:mx-0">
              <Leaf className="w-6 h-6 text-stone-600" />
            </div>

            {/* Title */}
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-stone-800 mb-3">
              {title}
            </h2>

            {/* Description */}
            <p className="text-base md:text-lg text-stone-600 mb-6">
              {description}
            </p>

            {/* CTA Button */}
            <a
              href="https://centerprihodnosti.si/"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 px-6 py-3 bg-stone-700 text-white font-semibold rounded-xl hover:bg-stone-800 transition-all shadow-md hover:shadow-lg text-sm"
            >
              {ctaText}
              <ExternalLink className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
