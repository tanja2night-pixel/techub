/** TecHub's public, read-only WordPress REST API. No WP credentials belong here. */
const WP_URL = (import.meta.env.VITE_WP_URL || 'https://cms.22digital.agency').replace(/\/+$/, '');
const API_URL = `${WP_URL}/wp-json`;

export type Language = 'sl' | 'en';
export type CmsSettings = Record<string, string>;

interface WpPost {
  id: number;
  slug: string;
  date: string;
  title: { rendered: string };
  excerpt?: { rendered: string };
  meta?: Record<string, unknown>;
  featured_image_url?: string;
}

function asString(value: unknown): string {
  return typeof value === 'string' ? value : '';
}
function cleanText(value: unknown): string {
  const html = asString(value);
  // Decode WordPress entities and remove any editor markup for text-only React props.
  if (typeof document === 'undefined') return html.replace(/<[^>]*>/g, '');
  // A detached textarea decodes character entities without creating active markup.
  const el = document.createElement('textarea');
  el.innerHTML = html.replace(/<[^>]*>/g, '');
  return el.value.trim();
}
function localized(sl: string, en: string, language: Language): string {
  return language === 'en' ? (en || sl) : sl;
}
function formatDate(value: string, language: Language): string {
  // Format the site's calendar date without shifting it across time zones.
  const parts = value.slice(0, 10).split('-').map(Number);
  if (parts.length !== 3 || parts.some(n => !Number.isFinite(n))) return value;
  const [year, month, day] = parts;
  if (language === 'sl') return `${day}. ${month}. ${year}`;
  return new Date(Date.UTC(year, month - 1, day)).toLocaleDateString('en-US', {
    day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC',
  });
}
function imageUrl(value: unknown): string {
  const url = asString(value);
  if (!url) return '';
  // WP's seeded media may reference a local path hosted on the React frontend.
  return url.startsWith('/') ? url : url;
}
function parseFeatures(value: unknown): { title: string; desc: string }[] {
  return asString(value).split('\n').map(line => line.trim()).filter(Boolean).map(line => {
    const [title, ...desc] = line.split('|');
    return { title: title.trim(), desc: desc.join('|').trim() };
  });
}

async function wpFetch<T>(path: string): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, { credentials: 'omit', cache: 'no-store' });
  if (!response.ok) throw new Error(`WordPress API: HTTP ${response.status} (${path})`);
  return response.json() as Promise<T>;
}

export interface CmsNews {
  id: number;
  title: string;
  date: string;
  excerpt: string;
  image: string;
  featured: boolean;
  link: string;
}
export async function getNews(language: Language): Promise<CmsNews[]> {
  const items = await wpFetch<WpPost[]>('/wp/v2/news?per_page=100&orderby=date&order=desc');
  return items.map(item => {
    const meta = item.meta || {};
    return {
      id: item.id,
      title: localized(cleanText(item.title?.rendered), cleanText(meta._techub_title_en), language),
      date: formatDate(item.date, language),
      excerpt: localized(cleanText(item.excerpt?.rendered), cleanText(meta._techub_excerpt_en), language),
      image: imageUrl(item.featured_image_url),
      featured: meta._techub_featured === true || meta._techub_featured === 1 || meta._techub_featured === '1',
      link: asString(meta._techub_external_link),
    };
  });
}

export interface CmsSpace {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  aboutDesc: string;
  features: { title: string; desc: string }[];
  image: string;
  color: string;
  showInterestButton: boolean;
}
export async function getSpaces(language: Language): Promise<CmsSpace[]> {
  const items = await wpFetch<WpPost[]>('/wp/v2/spaces?per_page=100&orderby=menu_order&order=asc');
  return items.map(item => {
    const meta = item.meta || {};
    const field = (name: string) => asString(meta[`_techub_${name}`]);
    return {
      id: item.slug,
      title: localized(cleanText(item.title?.rendered), cleanText(meta._techub_title_en), language),
      shortDesc: localized(field('short_desc_sl'), field('short_desc_en'), language),
      fullDesc: localized(field('full_desc_sl'), field('full_desc_en'), language),
      aboutDesc: localized(field('about_desc_sl'), field('about_desc_en'), language),
      features: parseFeatures(localized(field('features_sl'), field('features_en'), language)),
      image: imageUrl(item.featured_image_url),
      color: field('color'),
      showInterestButton: meta._techub_show_interest === true || meta._techub_show_interest === 1 || meta._techub_show_interest === '1',
    };
  });
}

export interface CmsTimeline {
  id: number;
  title: string;
  dateLabel: string;
  phase: string;
}
export async function getTimeline(language: Language): Promise<CmsTimeline[]> {
  const items = await wpFetch<WpPost[]>('/wp/v2/timeline?per_page=100&orderby=menu_order&order=asc');
  return items.map(item => ({
    id: item.id,
    title: localized(cleanText(item.title?.rendered), cleanText(item.meta?._techub_title_en), language),
    dateLabel: asString(item.meta?._techub_date_label),
    phase: asString(item.meta?._techub_phase),
  }));
}

let settingsRequest: Promise<CmsSettings> | undefined;
export function getSettings(): Promise<CmsSettings> {
  if (!settingsRequest) {
    settingsRequest = wpFetch<CmsSettings>('/techub/v1/settings').catch(error => {
      settingsRequest = undefined; // retry on a subsequent mount if the API was down
      throw error;
    });
  }
  return settingsRequest;
}
